async function getData(){
  var ans =0;
  //Have to put await here cause we need to wait for ajax to finish processing the request.
  await $.ajax({
      url: "http://hackathontest.duckdns.org:8000/latest/",
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
      },
      type: "GET", 
      dataType: "json",
      data: {
      },
      success: function (result) {
          
          //console.log("Result.data: "+result.data);
          ans=parseInt(result.data); //Set ans to the integer of our result (y value).
          //console.log("Ans: "+ans);
          
      },
      error: function () {
          console.log("error");
      }
  });
  //console.log("Outside ans: "+ans);
  return ans;
}
async function getSpeed(){
  var ans = new Array();
  //Have to put await here cause we need to wait for ajax to finish processing the request.
  await $.ajax({
      url: "http://hackathontest.duckdns.org:8000/speed/",
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
      },
      type: "GET", 
      dataType: "json",
      data: {
      },
      success: function (result) {
          
          //console.log("Result.data: "+result.data);
          
          
          ans.push(result.data[0]);
          ans.push(result.data[1]);
          //console.log("Ans: "+ans);
          
      },
      error: function () {
          console.log("error");
      }
  });
  //console.log("Outside ans: "+ans);
  return ans;
}

async function getTemp(){
  var ans =0;
  //Have to put await here cause we need to wait for ajax to finish processing the request.
  await $.ajax({
      url: "http://hackathontest.duckdns.org:8000/temp/",
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
      },
      type: "GET", 
      dataType: "json",
      data: {
      },
      success: function (result) {
          
          //console.log("Result.data: "+result.data);
          ans=parseInt(result.data); //Set ans to the integer of our result (y value).
          //console.log("Ans: "+ans);
          
      },
      error: function () {
          console.log("error");
      }
  });
  //console.log("Outside ans: "+ans);
  return ans;
}

async function getTwoHeart(){
  var ans = new Array();
  //Have to put await here cause we need to wait for ajax to finish processing the request.
  await $.ajax({
      url: "http://hackathontest.duckdns.org:8000/TwoHeart/",
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
      },
      type: "GET", 
      dataType: "json",
      data: {
      },
      success: function (result) {
          
          //console.log("Result.data: "+result.data);
          
          
          ans.push(result.data[0]);
          ans.push(result.data[1]);
          //console.log("Ans: "+ans);
          
      },
      error: function () {
          console.log("error");
      }
  });
  //console.log("Outside ans: "+ans);
  return ans;
}


function checkState(HratePrev, HrateAfter, speedPrev, SpeedAfter, temp){
  
  let speedDiff = (speedPrev-SpeedAfter);
  let HDiff = HratePrev-HrateAfter;
  if(speedDiff>=50 && HDiff>=50 ) return 1;
  else if(HDiff>=50 && temp>=200) return 2;
  else if(HDiff>=50) return 3;
  else return 0;
}
