from starlette.responses import Response
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
import requests
from bs4 import BeautifulSoup
app = FastAPI()

origins = [
    "http://localhost",
    "http://localhost:8080",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

items = [0,1]
speed = [60,70]
temp = [47]
@app.get('/coord/')
async def read_coords():
    return {'data':items}

@app.get('/latest/')
async def get_latest():
    return {'data':items[-1]}

@app.get('/speed')
async def get_speed():
    return {'data':(speed[-2],speed[-1])}

@app.get('/TwoHeart')
async def get_hearts():
    return {'data':(items[-2], items[-1])}

@app.get('/temp/')
async def get_temp():
    return {'data':temp[-1]}        

@app.post("/coord/{x}")
def post_coords(x: int):
    items.append(x)
    return {'data':items}

@app.post("/speed/{x}")
def post_speed(x: int):
    speed.append(x)
    return {'data':speed}

@app.post("/temp/{x}")
def post_temp(x: float):
    temp.append(x)
    return {'data':temp}

@app.get("/getValue/")
def get_value():
    page = requests.get("http://absb.duckdns.org:2019/")
    soup = BeautifulSoup(page.content, 'html.parser')
    data = float(str(soup))
    return {'data':data}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)